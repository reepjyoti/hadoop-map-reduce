package fr.eurecom.dsg.mapreduce;

import static org.junit.Assert.*;

/**
 * Created by reepjyoti on 02/11/16.
 */
public class WordCountCombinerTest {

}