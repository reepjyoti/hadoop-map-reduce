package fr.eurecom.dsg.mapreduce;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by reepjyoti on 05/11/16.
 */
public class PairTest {
    @Test
    public void run() throws Exception {

    }

    @Test
    public void main() throws Exception {

    }

}