package fr.eurecom.dsg.mapreduce;

import static org.junit.Assert.*;

/**
 * Created by reepjyoti on 05/11/16.
 */
public class StripesTest {

}