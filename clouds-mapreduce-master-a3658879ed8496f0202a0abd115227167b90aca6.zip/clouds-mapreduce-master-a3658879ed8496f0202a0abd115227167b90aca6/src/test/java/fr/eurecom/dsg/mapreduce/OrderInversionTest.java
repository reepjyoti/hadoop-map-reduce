package fr.eurecom.dsg.mapreduce;

import static org.junit.Assert.*;

/**
 * Created by reepjyoti on 07/11/16.
 */
public class OrderInversionTest {

}